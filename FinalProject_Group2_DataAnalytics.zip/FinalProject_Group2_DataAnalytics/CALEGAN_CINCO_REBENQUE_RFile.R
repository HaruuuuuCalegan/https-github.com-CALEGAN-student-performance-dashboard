library(shiny)
library(shinydashboard)
library(plotly)
library(DT)
library(dplyr)
library(readr)

# Load Data
StudentsPerformance <- read_csv("StudentsPerformance.csv")

# Generate dummy data if needed
set.seed(123)
StudentsPerformance$socioeconomic_status <- sample(c("High", "Medium", "Low"), size = nrow(StudentsPerformance), replace = TRUE)
StudentsPerformance$attendance_rate <- runif(nrow(StudentsPerformance), 0.5, 1.0)
StudentsPerformance$year <- sample(2018:2022, size = nrow(StudentsPerformance), replace = TRUE)
StudentsPerformance$average_grade <- rowMeans(StudentsPerformance[, c("math score", "reading score", "writing score")], na.rm = TRUE)

# UI
ui <- dashboardPage(
  dashboardHeader(title = "Student Performance Dashboard"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Overview", tabName = "overview", icon = icon("home")),
      menuItem("Trend Analysis", tabName = "trend", icon = icon("chart-line")),
      menuItem("Socioeconomic Impact", tabName = "socio", icon = icon("users")),
      menuItem("Data Table", tabName = "table", icon = icon("table"))
    )
  ),
  dashboardBody(
    tabItems(
      tabItem(tabName = "overview",
              fluidRow(
                valueBoxOutput("avg_grade_box"),
                valueBoxOutput("attendance_box"),
                valueBoxOutput("n_students_box")
              ),
              fluidRow(
                box(title = "Grade Distribution", width = 6, plotlyOutput("grade_hist")),
                box(title = "Attendance Distribution", width = 6, plotlyOutput("attendance_hist"))
              )
      ),
      tabItem(tabName = "trend",
              fluidRow(
                box(title = "Trends Over Time", width = 12, plotlyOutput("trend_plot"))
              )
      ),
      tabItem(tabName = "socio",
              fluidRow(
                box(title = "Average Grade by Socioeconomic Status", width = 12, plotlyOutput("socio_plot"))
              )
      ),
      tabItem(tabName = "table",
              fluidRow(
                box(title = "Student Data", width = 12, DTOutput("data_table"))
              )
      )
    )
  )
)

# Server
server <- function(input, output) {
  
  # Summary Stats
  output$avg_grade_box <- renderValueBox({
    avg_grade <- round(mean(StudentsPerformance$average_grade, na.rm = TRUE), 2)
    valueBox(avg_grade, "Average Grade", icon = icon("graduation-cap"), color = "blue")
  })
  
  output$attendance_box <- renderValueBox({
    avg_att <- paste0(round(mean(StudentsPerformance$attendance_rate, na.rm = TRUE) * 100, 1), "%")
    valueBox(avg_att, "Avg Attendance", icon = icon("calendar-check"), color = "green")
  })
  
  output$n_students_box <- renderValueBox({
    valueBox(nrow(StudentsPerformance), "Total Students", icon = icon("users"), color = "purple")
  })
  
  # Histograms
  output$grade_hist <- renderPlotly({
    plot_ly(StudentsPerformance, x = ~average_grade, type = "histogram", marker = list(color = 'steelblue')) %>%
      layout(title = "Average Grade Distribution", xaxis = list(title = "Average Grade"))
  })
  
  output$attendance_hist <- renderPlotly({
    plot_ly(StudentsPerformance, x = ~attendance_rate, type = "histogram", marker = list(color = 'orange')) %>%
      layout(title = "Attendance Rate Distribution", xaxis = list(title = "Attendance Rate"))
  })
  
  # Trend Plot
  output$trend_plot <- renderPlotly({
    trend_data <- StudentsPerformance %>%
      group_by(year) %>%
      summarise(avg_grade = mean(average_grade), avg_attendance = mean(attendance_rate))
    
    plot_ly(trend_data, x = ~year) %>%
      add_lines(y = ~avg_grade, name = "Avg Grade", line = list(color = 'royalblue')) %>%
      add_lines(y = ~avg_attendance * 100, name = "Attendance (%)", line = list(color = 'firebrick')) %>%
      layout(title = "Grades & Attendance Over Time", yaxis = list(title = "Scores / %"))
  })
  
  # Socioeconomic Impact Plot
  output$socio_plot <- renderPlotly({
    socio_data <- StudentsPerformance %>%
      group_by(socioeconomic_status) %>%
      summarise(avg_grade = mean(average_grade))
    
    plot_ly(socio_data, x = ~socioeconomic_status, y = ~avg_grade,
            type = "bar", marker = list(color = 'teal')) %>%
      layout(title = "Average Grades by Socioeconomic Status",
             xaxis = list(title = "Socioeconomic Status"),
             yaxis = list(title = "Average Grade"))
  })
  
  # Data Table
  output$data_table <- renderDT({
    datatable(StudentsPerformance, options = list(scrollX = TRUE, pageLength = 10))
  })
}

# Run the application
shinyApp(ui = ui, server = server)

